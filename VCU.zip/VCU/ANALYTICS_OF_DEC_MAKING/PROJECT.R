library(dplyr)

set.seed(123)

setwd("C:/Users/e_man/OneDrive/Desktop/Organization Decision Making")
#Scanning the colnames
colNames <- scan("alchemyBrokerData (1).csv", what="character", skip=0, nlines=1, sep=",")

characterColumns <- c("broker_name")

## All the variables are added to the numbercolumns
numerColumns <- c("Submissions_2014","Submissions_2015", "Submissions_2016",
                  "Submissions_2017", "Submissions_2018", "QuoteCount_2013",
                  "QuoteCount_2014", "QuoteCount_2015", "QuoteCount_2016", "QuoteCount_2017",
                  "QuoteCount_2018", "AvgQuote_2013", "AvgQuote_2014",
                  "AvgQuote_2015", "AvgQuote_2016", "AvgQuote_2017",
                  "AvgQuote_2018", "PolicyCount_2015", "PolicyCount_2016", "PolicyCount_2017",
                  "PolicyCount_2018", "GWP_2015","GWP_2016", "GWP_2017",
                  "GWP_2018", "AvgTIV_2015", "AvgTIV_2016",
                  "AvgTIV_2017", "AvgTIV_2018")

ColClasses <- character(length(colNames))

#Assigning character classeses to certain columns
ColClasses[colNames %in% characterColumns] <- "character"

##Assigning numeric classes to certain columns
ColClasses[colNames %in% numerColumns] <- "numeric"


count_rows <-188

##Reading the dataframe into a table
alchemy <- read.table("alchemyBrokerData (1).csv", skip=0, sep=",", nrows=count_rows,
                           colClasses = ColClasses, header=TRUE)



#Removing the rows with no submissions in any of 2015, 2016 and 2017
NArows<-which(rowSums(is.na(alchemy[,c(3:5)]))==3)
NArows

# % of data to be removed
(NROW(NArows)/NROW(alchemy))*100
# 13% 
alchemy<-alchemy[-NArows,]
alchemy
attach(alchemy)

##################TEST################
# a1<-alchemy[,c(1,7,2,8,3,9,4,10,5,11,6,12)]
# row.names(a1)<-1:NROW(a1)
#
# (s1<-which(is.na(a1$Submissions_2015)))
# (q1<-which(is.na(a1$QuoteCount_2015)))
#
# `%!in%` = Negate(`%in%`)
#
# which(s1%!in%q1)
#
# which(is.na(Submissions_2015))
# w1<-which(s1%!in%q1)
# s1[w1]
########################################
names(alchemy)
sub1<-alchemy[,c(1:6)]
head(sub1)
#Loading the mice package
library(mice)

#Loading the following package for looking at the missing values

library(VIM)
library(lattice)
?md.pattern
#Missing value pattern
md.pattern(sub1[,c(2:6)])
#Impute using Linear Regression
#mice is a function that is used to fill na values into a seperate data frame
#complete is used to fill the data frame
#mice_imputes is used to impute the data for missing values using the classification and regression training model
mice_imputes = mice(sub1[,c(2:6)], m=5, maxit = 40, method = "cart")

imputed_data = complete(mice_imputes,3)

#Replacing the imputed_data in the alchemy dataset
alchemy[,c(2:6)]<-imputed_data

#Replacing NAs with zero in the Quotes and Policy columns

library("imputeTS")
alchemy[,c(7:30)] <- na.replace(alchemy[,c(7:30)], 0.01)

which(alchemy$PolicyCount_2015 == 0)
which(alchemy$GWP_2015 == 0)


#Taking the ratios to measure performance
#QuoteRatios
alchemy$qr_2015<-(QuoteCount_2015/Submissions_2015)
alchemy$qr_2016<-(QuoteCount_2016/Submissions_2016)
alchemy$qr_2017<-(QuoteCount_2017/Submissions_2017)

#HitRatios
alchemy$hr_2015<-(PolicyCount_2015/QuoteCount_2015)
alchemy$hr_2016<-(PolicyCount_2016/QuoteCount_2016)
alchemy$hr_2017<-(PolicyCount_2017/QuoteCount_2017)

#SuccessRatios
alchemy$sr_2015<-(PolicyCount_2015/Submissions_2015)
alchemy$sr_2016<-(PolicyCount_2016/Submissions_2016)

alchemy$sr_2017<-(PolicyCount_2017/Submissions_2017)

names(alchemy)

save
##using all the variables except from the broker names
alchemy_Data_model<-alchemy[,2:39]

##Saving the rda file
save(alchemy,alchemy_Data_model,file="alchemist.rda")

alchemy_Data_model<-alchemy_Data_model %>%
  mutate(upOrDown=if_else(GWP_2018>GWP_2017,"Up","Down"))



#Replace 
alchemy_Data_model[,c(30:39)] <- na.replace(alchemy_Data_model[,c(30:39)], 0.0001)
sum(is.na(alchemy_Data_model))

library(dummies)
alchemist=dummy.data.frame(alchemy_Data_model)
alchemist=dummy.data.frame(alchemy_Data_model,names=c("upOrDown"))
alchemist<-alchemist[,1:38]
str(alchemist)
alchemist$upOrDownDown<-as.numeric(alchemist$upOrDownDown)
head(alchemist,1)
alchemist
str(alchemist)

#Center and scale the data to prepare for Cluster and PCA analysis
alchemist<- scale(alchemist, center=TRUE, scale=TRUE)
summary(alchemist)
#Cluster the customers into seven groups using k-means clustering
alchemistkmeans=kmeans(alchemist,centers = 5)
                     
alchemistkmeans
                                           
library("cluster")
clusplot(alchemist,alchemistkmeans$cluster,col.p=alchemistkmeans$cluster)
alchemistkmeans

sum(is.na(alchemistkmeans))
                                           
mean_of_variables_in_cluster<-as.data.frame(aggregate(.~ alchemistkmeans$cluster, FUN=mean, data=alchemy_Data_model))
mean_of_variables_in_cluster
warnings()
##Why s it returning NA?
sd_of_variables_in_cluster<-as.data.frame(aggregate( .~ loandfkmeans$cluster, FUN=sd, data=loandf))
sd_of_variables_in_cluster
                                           
                                           
                                           ##silhoutte, screeplot, loadings matrix , cube of principal components
                                           ##2###
                                           
                                           ##plotting against principal components
alchemistPCA <- prcomp(alchemist, retx=TRUE)
summary(alchemistPCA)
screeplot(alchemistPCA)
alchemistPCA$rotation[,1:4]
plot(alchemistPCA$x[,1:2],col=alchemistkmeans$cluster,pch=alchemistkmeans$cluster)
                                           
                                           
                                           
                                           #annual income variation is explained to a huge degree by principal component1
                                           
plot(alchemistPCA$x[,1:2], col=alchemistkmeans$cluster, pch=alchemistkmeans$cluster)                     

###################################################################

alchemy_Data_model$upOrDown

nrow(alchemy_Data_model)

##segregation into test and train data
set.seed(12345)
trainalcRows<- createDataPartition(alchemy_Data_model$upOrDown,
                                   p = 0.7,
                                   list=FALSE)

trainalcRows1 <- alchemy_Data_model[trainalcRows,]
nrow(trainalcRows1)
trainalcRows
testRowz <- alchemy_Data_model[-trainalcRows,]
nrow(testRowz)
table(alchemy_Data_model$upOrDown)

alcWeights <- numeric(nrow(trainalcRows1))
alcWeights[trainalcRows1$upOrDown == "Up"] <- 1
alcWeights[trainalcRows1$upOrDown == "Down"] <- 2

trainalcRows1$upOrDown<-as.factor(trainalcRows1$upOrDown)
testRowz$upOrDown<-as.factor(testRowz$upOrDown)
##logistic regression
alc_model <- glm(upOrDown ~ .,
                 data=trainalcRows1,weights=alcWeights,
                 family=binomial("logit"))


names(trainalcRows1)
#prediction of test data
testRowz_predict <- predict(alc_model,newdata=testRowz,type="response")
head(testRowz_predict,10)
length(testRowz_predict)
table(testRowz_predict)

##classification 
alcPredictClass <- character(length(testRowz_predict))
alcPredictClass[testRowz_predict < 0.5] <- "Down"
alcPredictClass[testRowz_predict >= 0.5] <- "Up"
alcPredictClass
##confusion table
alc_confusion_table <- table(testRowz$upOrDown, alcPredictClass)
alc_confusion_table
sum(diag(alc_confusion_table)/sum(alc_confusion_table))

##plotting of ROC curve

alcPred <- prediction(testRowz_predict,
                      testRowz$upOrDown,
                      label.ordering=c("Down", "Up"))

alcPerf <- performance(alcPred, "tpr", "fpr")
plot(alcPerf,col=1)

#ROC curve....


#=================================================================================
##Root mean squared error 
#classification
###classification

library(rpart)

alcRpart <- rpart(upOrDown ~., data = trainalcRows1)
alcRpartPredict <- predict(alcRpart, newdata = testRowz, type="prob")
alcRpartPredict
alcRpartPred <- prediction(alcRpartPredict[,2],
                              testRowz$upOrDown,
                              label.ordering=c("Down", "Up"))
alcRpartPerf <- performance(alcRpartPred, "tpr", "fpr")

alcRpartPredict1 <- predict(alcRpart, newdata = testRowz, type="class")

alcLRCM1 <- table(testRowz$upOrDown, alcRpartPredict1)
alcLRCM1
sum(diag(brokerLRCM1)/sum(brokerLRCM1))

plot(alcRpartPerf,col=1)

plot(brokerRpart)
text(brokerRpart)




#==========================================================
#====================================================================
#Random forest
#=============
#Random Forest
library(randomForest)
?randomForest

alcRF <- randomForest(upOrDown ~ .,
                      data = trainalcRows1, importance=TRUE)
alcRF$importance

AlPredictRF <- predict(alcRF, newdata=testRowz, type="response")
AlPredictRF
(alcRFConfusion <- table(testRowz$upOrDown, AlPredictRF))
sum(diag(alcRFConfusion)/sum(alcRFConfusion))


table(testRowz$upOrDown, AlPredictRF)
mean(testRowz$upOrDown == AlPredictRF)

testRowz$upOrDown

AlPredictRF_1 <- predict(alcRF, newdata=testRowz, type="prob")
head(AlPredictRF_1)
alc_RF <- prediction(AlPredictRF_1[,2],
                    testRowz$upOrDown,
                    label.ordering=c("Down", "Up"))

alc_RF_1 <- performance(alc_RF, "tpr", "fpr")
plot(alc_RF_1,col=1)

#ROC curve....

#=========================================================================


##Comparision of all values..
plot(alcPerf, col=1)
plot(alcRpartPerf, col=2, add = TRUE)
plot(alc_RF_1, col=3, add = TRUE)
legend("bottomright",c("LR", "CT", "RF"), fill=1:3, ncol=2,cex = 0.5)

#==========================================================================


glm.probs <- predict(alc_model,
                     newdata = alchemy,
                     type = "response")



glm.pred <- ifelse(glm.probs > 0.5, "Up", "Down")
glm.probs

write.csv(glm.pred,file = "project_2.csv")
write.csv(glm.probs, file = "project_2.csv")
)
