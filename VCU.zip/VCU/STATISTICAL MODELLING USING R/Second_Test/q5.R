#part a
#dependent variable is house sales
#independent variable is population.


#Part b
setwd("C:/Users/e_man/OneDrive/Desktop/SCMA")
getwd()
housing_df<-read.csv("housing.csv")

#Part c
model_housing<-lm(housing_df$house_sales~housing_df$population)
plot(model_housing)


#Part d

#shapiro test
plot(density(housing_df$house_sales))
shapiro.test(housing_df$house_sales)
#H0:data is  normally distributed.
#H1:data is not normally distributed.
#given data is normally distributed.


shapiro.test(housing_df$population)
#H0:data is  normally distributed.
#H1:data is not normally distributed.
#given data is NOT normally distributed.

plot(density(housing_df$population))




##test for autocorrelation 


#durbin watson test

dwtest(model_housing)
#H0: Residuals are independent of each other
#h1:residuals are not independent of each other
# the value is away from 2 and the null hypothesis is rejected at 99% confidence interval thus, the residuals are dependent on each other.


#multicollinearity test
#vif(model_housing)
## Theere is only one independent variable , hence there is no need of conducting the VIF test.

#heteroskedascity test
bptest(reg_model)
#H0: residual of the student performance is homoskedastic
#H1:residual of the student performance is not homoskedastic

# The residuals are homoskedastic.

## The violations are that the population is not normally distributed. and there exists significant autocorrelation.

#Part e

housing1_df<-read.csv("housing1.csv")
#Part f
# The independent variable is loan availability  and population and dependent vaiable are sales

#Part g
model_loan<-lm(housing1_df$house_sales~housing1_df$population+housing1_df$loan_availability)



#Part h

#shapiro test
plot(density(housing1_df$house_sales))
shapiro.test(housing1_df$house_sales)
#H0:data is  normally distributed.
#H1:data is not normally distributed.
#given data is normally distributed.


shapiro.test(housing1_df$population)
#H0:data is  normally distributed.
#H1:data is not normally distributed.
#given data is NOT normally distributed at 95% confidence interval

plot(density(housing1_df$population))

shapiro.test(housing1_df$loan_availability)
#H0:data is  normally distributed.
#H1:data is not normally distributed.
#given data is normally distributed.



##test for autocorrelation 


#durbin watson test

dwtest(model_loan)
#H0: Residuals are independent of each other
#h1:residuals are not independent of each other
# the value is close to two thus inferrring that the residuals are  independent of each other , futhermore , p value falls withing the acceptance region.

vif(model_loan)
#multicollinearity test
#vif(model_housing)
## The VIF is below 10 , thus there exists no multicollinearity.

#heteroskedascity test
bptest(model_loan)
#H0: residual of the student performance is homoskedastic
#H1:residual of the student performance is not homoskedastic

# the residuals are homoskedastic 

