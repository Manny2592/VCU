
library(lmtest)
#part (a)
#The dependent varaible is student_achievements
#The independent variable are faculty credentials (FAM), the influence of their peer group in the school (PEER) and school facilities (SCHOOL). 

#part (b)
setwd("C:/Users/e_man/OneDrive/Desktop/SCMA")
getwd()
student_df<-read.csv("students.csv")
#part (c)
reg_model<-lm(student_df$ACHV~student_df$FAM+student_df$PEER+student_df$SCHOOL)
summary(reg_model)
# R squared value is 0.20
## None of the values seem to be significant at  95% confidence interval.
plot(reg_model)

#part (d)

#shapiro test

shapiro.test(student_df$ACHV)
#H0:data is  normally distributed.
#H1:data is not normally distributed.
#given data is normally distributed.

shapiro.test(student_df$FAM)
#H0:data is  normally distributed.
#H1:data is not normally distributed.
#given data is normally distributed.

shapiro.test(student_df$PEER)
#H0:data is  normally distributed.
#H1:data is not normally distributed.
#given data is normally distributed.

shapiro.test(student_df$SCHOOL)
#H0:data is  normally distributed.
#H1:data is not normally distributed.
#given data is normally distributed.


##test for autocorrelation 


#durbin watson test

dwtest(reg_model)
#H0: Residuals are independent of each other
#h1:residuals are not independent of each other
# the value is close to 2 , so there exists little if possibly no autocorrelation. . .
#no autocorrelation present .


#multicollinearity test
vif(reg_model)
## The formulae for vif -1/1(1-Rsquared)
# All the values exhibiting a vif of greater than 10 , hence there is high multicollinearity amongst the variables .
# This assumption is violated.

#heteroskedascity test
bptest(reg_model)
#H0: residual of the student performance is homoskedastic
#H1:residual of the student performance is not homoskedastic

# The residuals are homoskedastic.


#part (e)
names(student_df)
cor(student_df[2:4])
# All have a correlation of greater than 0.9.
 # selecting only one variable from the model.
#Family
reg_model_1<-lm(student_df$ACHV~student_df$FAM)
summary(reg_model_1)
# t- stat is highly significant indicating the variable has a huge influence on the data.