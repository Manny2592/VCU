

#filename = Q1.R
#write your codes below, each part should be below respective items

#prequisite
library(car)

#part (a)

setwd("C:/Users/e_man/OneDrive/Desktop/SCMA")
nss_data<-read.csv("all_india_nss68.csv")


#part (b)

nss_data$marital_status_desc=recode(nss_data$Marital_Status,"1='Never married';2='Currently married';3='Widowed';4='seperated'")

#part (c)

nss_data$state_code=recode(nss_data$state,"1='JK';2='HPPP';3='PB';4='CH';5='UT';6='HR';7='DL';8='RJ';9='UPPP';10='BR';11='SK';12='AR';13='NG';14='MR';15='MZ';16='TR';17='MG';18='AS';19='WB';20='JH';21='OD';22='CG';23='MP';24='GJ';25='DM';26='DN';27='MH';28='AP';29='KAAA';30='GOAAA';31='LKSDP';32='KE';33='TN';34='PY';35='AN'")
#part (d)
nss_data_mh<-nss_data[which(nss_data$state_code=='MH'),]
x2<-nss_data_mh[nss_data_mh$MPCE_URP<90000,1]
nss_data_mh<-nss_data_mh[x2,]
head(nss_data_mh,2)

#part (e)
min_income<-aggregate(nss_data$MPCE_URP,by=list(nss_data$state_code),FUN=min)
colnames(min_income)<-c("state","minn_income")
min_income<-min_income[order(min_income$minn_income),]
#part (f)
?aggregate
income_std<-aggregate(nss_data$MPCE_URP,by=list(nss_data$state_code,nss_data$Sector),FUN=sd)
colnames(income_std)<-c("state","sector","income")
income_std<-income_std[order(-income_std$income),]

#part (g)
a1=max(income_std$income)
income_std[income_std$income==a1,1]
#Himachal pradesh has the highesr standard deviation. . 

#part (h)
index<-floor(0.666*nrow(nss_data))
seq_gen<-sample(seq_len(nrow(nss_data)),size=index)

train<-nss_data[seq_gen,]
test<-nss_data[-seq_gen,]



#part (i)
reg_train<-lm(vegtt_v~MPCE_URP,data=train)
summary(reg_train)
summary(aov(reg_train))
#a
#a)1. Yes , income is significant at 5 % significance as p-value<0.05...furthermore calculated t value is 52.44 which is higher than t-critical at (df=67704 and at 95% )confidence interval, thus rejecting the null hypothesis that the variables are not significant.
#a)2. Yes , income is significant at 1 % significance as p-value<0.01...furthermore calculated t value is 52.44 which is higher than t-critical at (df=67704 and at 99%) confidence interval thus rejecting the null hypothesis that the variables are not significant .
#a)3. Yes , income is significant at 1 % significance as p-value<0.001...furthermore calculated t value is 52.44 which is higher than t-critical at (df=67704 and at 99.9%) confidence interval thus rejecting the null hypothesis that the variables are not significant .

cor(train$vegtt_v,train$MPCE_URP)
cor(train$vegtt_v,train$MPCE_URP)*cor(train$vegtt_v,train$MPCE_URP)
#b
#R squared is 0.03903 , R squared is the  square value of correlation of the two variables, both the income and vegetable consumption are positively correlated. 
#R squared can be calculated by the (squared  sum of regression variables /squared sum of y variables)
#(squared  sum of regression variables /squared sum of y variables)+(squared  sum of error /squared sum of y variables)=1.
# 3.9 % of variance of vegeatble consumption can be explained by our obtained model , and the rest could be possibly explained by errors.

#c
cor(train$vegtt_v,train$MPCE_URP)
#The pearson product correlation gives a value 0.19 which states that the income is capable of explaining 19% variance of vegetable consumption. 

#d pvalue <2e^-16.
#e
summary(aov(reg_train))
#HO:The coeffiecient of income is 0 and adds no impact to our model.
#H1:The coefficeient of income is not 0 and contributes significantly to the obtained model.
#P-value<0.05 of obtained F statistic.
#since there is only one independent variable, the same result can be achieved by a regular t -test.
#The result being the slope of coeffiecient of 0 is not 0 , and does contribute significantly to the model.

#f
grep("vegtt_v", colnames(test))
names(test)
test$model_vegett_value<-predict(reg_train,test)
a<-test[,c(310,387)]
a
#residuals are high. thus , there is high error in prediction.

#part (j)
a<-train$fruitstt_v+train$vegtt_v
reg_train_1<-lm(a~hhdsz+FSU_number,data=train)
summary(reg_train_1)
summary(aov(reg_train))
#a
#a)1. Yes , independent variables(hhdsz AND FSU_numer) are significant at 5 % significance as p-value<0.05...furthermore calculated t value is -70 and -32 which is higher than t-critical at (df=67704 and at 95% )confidence interval, thus rejecting the null hypothesis that the variables are not significant and claiming they indeed are significant.
#a)2. Yes , independent variables(hhdsz AND FSU_numer) are significant at 1 % significance as p-value<0.05...furthermore calculated t value is -70 and -32 which is higher than t-critical at (df=67704 and at 99% )confidence interval, thus rejecting the null hypothesis that the variables are not significant and claiming they indeed are significant.
#a)3. Yes , independent variables(hhdsz AND FSU_numer) are significant at .01 % significance as p-value<0.05...furthermore calculated t value is -70 and -32 which is higher than t-critical at (df=67704 and at 99.9% )confidence interval, thus rejecting the null hypothesis that the variables are not significant and claiming they indeed are significant.


cor(a,train$MPCE_URP)
cor(train$vegtt_v,train$MPCE_URP)*cor(train$vegtt_v,train$MPCE_URP)
#b
#R squared is 0.05672 , R squared is the  square value of correlation of the two variables respectively , both the ((family size),(a)) and ((hhsdz),(a))are positively correlated. 
#R squared can be calculated by the (squared  sum of regression variables /squared sum of y variables)
#(squared  sum of regression variables /squared sum of y variables)+(squared  sum of error /squared sum of y variables)=1.
# 5.6 % of variance ocan be explained by our obtained model , and the rest could be possibly explained by errors.

#c
cor(a,train$MPCE_URP)
cor(a,train$FSU_number)

#d pvalue <2e^-16.
#e
summary(aov(reg_train_1))
#HO:The coeffiecient of  family size and hhsdz is 0 and adds no impact to our model.
#H1:The coefficeient of family size and hhsdz is not 0 and contributes significantly to the obtained model.
#P-value<0.05 of obtained F statistic.
#The result being the slope of coeffiecients are not , and does contribute significantly to the model.

#f
grep("hhdsz", colnames(test))
grep("FSU", colnames(test))
names(test)
test$model_fruitnvegett<-predict(reg_train,test)
a<-test[,c(4,24,388)]
a
#residuals are high. thus , there is high error in prediction.




#part (k)
cor(nss_data$goatmeat_q,nss_data$MPCE_URP)
reg_goat<-lm(nss_data$goatmeat_q~nss_data$MPCE_URP )
summary(reg_goat)
# The r squared value is extremely low of 0.05% and would not render an accurate model for the data.
summary(aov(reg_goat))
#The mean square of residuals is very low , and indicates no error.The (square sum of error /square sum of family size and hhsdz) is relatively nil. Thus even though the regression component contributes more significantly than the  significantly than the errors, the R -squared value is too low to use the model of prediction.

#part (l)

reg1<-lm(wheattotal_q~Sector,data=train)
reg2<-lm(wheattotal_q~factor(Sector),data=train)
summary(reg1)
summary(reg2)
summary(aov(reg_train))
#In interpretation there is no difference , because sector is dichotomous two results 1 =urban and  rural =2.
#the number of dummy variables is no.of factors-1.
#Since there are only two factors, only coefficient is generated with the exception of the intercept in both the models.

#part (m)
reg1<-lm(wheattotal_q~Region,data=train)
reg2<-lm(wheattotal_q~factor(Region),data=train)
summary(reg1)
summary(reg2)
summary(aov(reg_train))
#In interpretation there is a difference , because Region has a total of 6 treatments.
#the number of dummy variables is (no.of factors-1).
#Since there are only six factors, 5 coefficient is generated with the exception of the intercept reg2.
#Each value can be plugged in when the correponding region is to be analyzed . Region 1 can be calculated using 0 plugins.




#part (n)

summary(aov(train$wheattotal_q ~   train$MPCE_URP))
# both are continuous variables , and there is only one treatment as indicated by the df=1 in mpce_urp.degree of freedom is 1.
summary(aov(train$wheattotal_q ~   train$state_code))
#there are 34 treatments in state variable , as indicated by the degrees of freedom.
#H0:All the means are equal . H1:Atleast one amongst the means aree unequal 
#we reject the null hypothesis and the mean across all treatments are unequal , as calculated F statistic is 4083 which is greater that the F crtical value.

#part (o)

fit = lm(fruitt_total ~ Sector + hhdsz + MPCE_URP + Sex + Age + Education, data = nss_data)
summary(fit)

#Income Elasticity
#coefficient of income is 1.729
1.729e-03 * mean(nss_data$MPCE_URP)/mean(nss_data$fruitt_total)



#part (p)

nss_data$price=nss_data$fruits_df_tt_v/nss_data$fruitt_total
fit = lm(fruitt_total ~ Sector + hhdsz + MPCE_URP + Sex + Age + Education, data = nss_data)
summary(fit)
#Price elasticity of demand
fit = lm(fruitt_total ~ Sector + hhdsz + MPCE_URP + Sex + Age + Education + price, data = nss_data)
#price coefficient* mean(data.clean$price)/mean(data.clean$FVQ)


#part (q)
Gini(nss_data$MPCE_URP, corr=FALSE, na.rm = TRUE)
#39% of the population have most of the wealth.
pov(nss_data$MPCE_URP,2000,type=c("Watts"),na.rm=TRUE)
#39% of the population have most of the wealth.
plot(Lc(nss_data$MPCE_URP,n=rep(1,length(nss_data$MPCE_URP)),plot=TRUE))


