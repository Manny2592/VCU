a<-rpois(100,lambda = 2)
plot(density(a))


b<-rweibull(100,shape = 1.5,scale=2)


plot(density(b))
