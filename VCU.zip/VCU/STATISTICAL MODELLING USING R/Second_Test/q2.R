#part (a)
setwd("C:/Users/e_man/OneDrive/Desktop/SCMA/New folder")
getwd()
source("TukeyHSD-1.R")

#part (b)

plot(TukeyHSD(x=ANOVA, 'data$x', conf.level=0.01) , las=1 , col="brown" )
plot(TukeyHSD(x=ANOVA, 'data$x', conf.level=0.5) , las=1 , col="brown" )
Plotplot(TukeyHSD(x=ANOVA, 'data$x', conf.level=0.9) , las=1 , col="brown" )
plot(TukeyHSD(x=ANOVA, 'data$x', conf.level=0.99) , las=1 , col="brown" )
