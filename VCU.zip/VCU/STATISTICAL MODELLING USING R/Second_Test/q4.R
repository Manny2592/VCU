#part (a)
setwd("C:/Users/e_man/OneDrive/Desktop/SCMA")
getwd()
# The independent variable is Number of Injury Incidents (Y)
#proportion of Total Flights (N)


#part (b)
airline_df<-read.csv("airlines.csv")

#part (c)
model_accidents<-lm(airline_df$Y~airline_df$N)
summary(model_accidents)
plot(model_accidents)
summary(aov(model_accidents))
#graphically it is visible the residuals dependent of each other , thus there possibly exists autocorrelation
#residuals are normally distributed
##R square value is 0.4872 thus showing that (sum of squares of regression/sum of squares of no. of accidents ) is very high. 
# using an anova test , airline is significantly contributing towards the slope of the model at 95% confidence interval, howver at 99% confidence interval it would not contribute towards the model.
#part(d)

#part (d)
library(lmtest)
#shapiro test

shapiro.test(airline_df$Y)
#H0:data is  normally distributed.
#H1:data is not normally distributed.
#given data is normally distributed.

shapiro.test(airline_df$N)
#H0:data is  normally distributed.
#H1:data is not normally distributed.
#given data is normally distributed.

##test for autocorrelation 


#durbin watson test

dwtest(model_accidents)
#H0: Residuals are independent of each other
#h1:residuals are not independent of each other
# the value is close to 2 , so there exists little if possibly no autocorrelation. . .
#no autocorrelation present .


#multicollinearity test
vif(model_accidents)
## No multicollinearity as there exists a single independent variable.

#heteroskedascity test
bptest(model_accidents)
#H0: residual of the airline accidents performance is homoskedastic
#H1:residual of the airline accidents is not homoskedastic

# The residuals are homoskedastic at a 95% confidence interval but would be heteroskedastic at a 99% confidence interval.


