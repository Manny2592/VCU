a=rnorm(100)
pdf=dnorm(a,10,50)

plot(density(pdf))

