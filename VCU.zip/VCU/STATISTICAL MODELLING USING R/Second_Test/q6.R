#part a

setwd("C:/Users/e_man/OneDrive/Desktop/SCMA/New folder")
getwd()
distr<-source("Q5-source.R")
names(distr)
head(distr)
#part b
ks.test(d1,d2)

# h0: the two distributions are similar in shape and scale

#h1:the two distributions are not similar, and are coming from different distributions.

# The null hypothesis is accepted and the two distributions are similar in shape and scale.

#part c

ks.test(d3,d4)
# h0: the two distributions are similar

#h1:the two distributions are not similar, and are coming from different distributions.

# The null hypothesis is rejected andn the two distributions are not similar and are coming from different sources..

#part d
ks.test(d5,d6)
# h0: the two distributions are similar

#h1:the two distributions are not similar, and are coming from different distributions.

# The null hypothesis is accepted and the two distributions are similar.

