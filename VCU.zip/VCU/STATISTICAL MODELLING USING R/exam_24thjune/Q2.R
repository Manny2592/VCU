#part (a)


#part (b)


#part (c)


#part (d)


#part (e)
