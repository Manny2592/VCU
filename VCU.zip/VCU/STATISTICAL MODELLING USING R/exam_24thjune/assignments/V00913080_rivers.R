#a
setwd("C:/Users/e_man/OneDrive/Desktop/SCMA/exam_24thjune")
getwd()
rivers<-read.csv("rivers.csv")

#b
str(rivers)
dim(rivers)
rivers
rivers=rivers[,-c(1)]

#c
model_nitrogen<-lm(Nitrogen~.,data=rivers)
summary(model_nitrogen)
##Individually no variable is significant at 95% confidence interval...
##ComIndle is significant at 90% confidence interval...

#H0:Agriculture=0
##H1:Agriculture!=0
##The null hypthesis is accepted and agricultural is not a significant variable at 95% confidence interval

##H0:Residential=0
##H1:Residential!=0
##The null hypthesis is accepted and residential is not a significant variable at 95% confidence interval...

##H0:Forest=0
#H1:Forest!=0
##The null hypthesis is accepted and forest is not a significant variable at 95% confidence interval...

##H0:ComIndl=0
#H1:ComIndl!=0
##The null hypthesis is accepted and ComIndl is not a significant variable at 95% confidence interval...However, it is a significant variable at 90% confidence interval...

##Collectively,howvever the variables are significant at 99.9% confidence interval...
summary(aov(model_nitrogen))
##H0:slope of nitrogen is effected by Forest=Residential=ComIndl=0
##H1:Atleast one of the variables is contributing towards the model. . .
## Forest is significantly contributing towards the model as the slope of nitrogen content  is greatly dependent on the forest..
plot(model_nitrogen)
##residuals are relatively homoskedastic ,howvever the 19th observation and the 4th observation are causing residuals that are overall making the model heteroskedastic...
##residuals are normally distributed...

#d
##Individually no variable is significant at 95% confidence interval...
##ComIndle is significant at 90% confidence interval...
summary(model_nitrogen)
##Adjusted R-squared is 0.6319. . with the addition of a new variable to the model the R squared value can decrease to 0.6319 from the existing R squared value of 0.7094....

##E
summary(model_nitrogen)
summary(aov(model_nitrogen))
##H0:slope of nitrogen is effected by Forest=Residential=ComIndl=0
##H1:Atleast one of the variables is contributing towards the model. . .
#overall regression is significant as per the F test (significant at 99.9% confidence interval)as forest is contributing maximum towards the slope of the model ....

##F
##Individually the variables are not significant to the regression line, as all the t-stat values are below the t-stat value of 1.96 at a 95% confidence interval ,thus the individual contribution is lacklustre
##Collectively , none of the variable means are similar and all exhibit a different variance contributing significantly to the model , exhibiting a property where in our regression model is a good representation of the population.
#This phenomenon occurs when there is an interaction of the variables .

##g
boxplot(rivers$Rsdntial)
mean(rivers$Rsdntial)
median(rivers$Rsdntial)
difference<-(mean(rivers$Rsdntial)-median(rivers$Rsdntial))
##outliers are present in the data, the 5th observation is way beyond the 5 th quartile value ...
##this outlier has a significant impact on the mean of the data , as denoted by the 
difference
##Since this value is significantly much offset from the mean , either it could be an incorrect entry or the residential impact on the river in this observation is very /extremely high


##h
boxplot(rivers$ComIndl)
mean(rivers$ComIndl)
median(rivers$ComIndl)
difference<-(mean(rivers$ComIndl)-median(rivers$ComIndl))
##A total of 3 observations exist as outliers ,however not as offset as in the residential variable 
#Since the observations are not as offset as in this context , the mean and median values are not as different as can be seen
difference

##i
rivers<-read.csv("rivers.csv")
head(rivers,5)
rivers1<-rivers[-c(4,5),]
rivers1

##j
rivers1<-rivers1[,-c(1)]
model_nitrogen_rivers1<-lm(Nitrogen~.,data=rivers1)
summary(model_nitrogen_rivers1)


##k
summary(model_nitrogen_rivers1)
##Only the intercept is significant at 95% confidence interval...
##adjusted R-squared is 0.8452 with the addition of new variables ..

##l
summary(aov(model_nitrogen_rivers1))
##H0:Forest =Residential=ComIndl=0
##H1:Atleast one coeffiecient is not 0...
##F-stat is significant and less than 0.05 ,so all the variables collectively are significantly contributing towards the model..
##All the variables are different from each other


##m 
#The Rsquared values are greater in the obtained model in which the two rivers are removed ....
#Being outliers these rivers were not contributing significant variance towards the dependent variable .i.e nitrogen

##n
rivers1
library(car)
vif(model_nitrogen_rivers1)
##Agriculture and forest are greater than 8.
rivers2=rivers1[,-c(1,2)]
head(rivers2)


#o
model_nitrogen_rivers_2=lm(Nitrogen~.,data=rivers2)
summary(model_nitrogen_rivers_2)
##Only the intercept is significant at 95% confidence interval
##R squared adjusted is 0.5168 which states with the addition of extra variables , the R squared value could potetially decrease

#p
summary(aov(model_nitrogen_rivers_2))
# As per the anova  test , all the Residential variables is fundamentally distinct....
summary(model_nitrogen_rivers_2)
#H0:Agr =Forest=Residential=0
#H1:Atleast one variable is not zero..

##The null hypothesis is rejected stating that all the variables are significantly contributing towards the model
##This result is derived from the F-stat derived p value.

#Q
vif(model_nitrogen_rivers_2)
#there exists new multicollinearity in the updated model.

#r
summary(model_nitrogen_rivers_2)
#nitrogen_content=.7933+.1947(Residential)+0.2685(ComIndl)

##s
final_eqn<-step(model_nitrogen_rivers_2)
summary(final_eqn)
##The final equation is .80938+.24309(Residential)
