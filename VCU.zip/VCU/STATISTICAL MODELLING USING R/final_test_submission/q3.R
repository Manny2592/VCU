
setwd("C:/Users/e_man/OneDrive/Desktop/SCMA/FINAL TEST")
getwd()
cereals <- read.csv("cereal.csv", header=TRUE)
names(cereals)
head(cereals,10)
# FACTOR ANALYSIS FOR DATA REDUCTION

cereals.1 <- cereals[,c(2:9)]
View(cereals.1)

#Principal Component Analysis
cereals.pca <- prcomp(cereals.1) 
summary(cereals.pca)
##A mammoth 58.82% of the variance is explained by the principal component 1 .
##A mammoth 38.05% of the variance is explained by principal component 2
##2.9% of variance is explained by principal component 3.
names(cereals.pca)
cereals.pca
# TO DECIDE HOW MANY COMPONENTS TO RETAIN
screeplot(cereals.pca, type="lines")

## As per screeplot , only 3 components are selected .

#Scatterplots of the Principal Components

plot(cereals.pca$rotation[,1],cereals.pca$rotation[,2])
text(cereals.pca$rotation[,1],cereals.pca$rotation[,2], cex=0.7, pos=4, col="red")  
names(cereals.1)
##Sodium variable is most distant .
#Potassium is also relatively distant .
##Remaining variables are contributing to the pricipal components as their variances are similar.


plot(cereals.pca,type="l")

biplot(cereals.pca)



# Maximum Likelihood Factor Analysis
# entering raw data and extracting 3 factors 
# with varimax rotation 
cereals.factor  <- factanal(cereals.1[,-c(19)], 3, rotation="varimax", scores = c( "regression"))
print(cereals.factor, digits=2, cutoff=0.5, sort=TRUE)

#H0:model is not a bad fit
#H1:model is a bad fit 

#Null is accepted , this could be due to the high variation is sodium and potassium.

##Protein , Fiber and Potassium are having maximum correlation with factor 1 .Factor 1 is explaining a 97% variance of potassium.
##Fat,Calorie and sugar are having a very high correlation with factor 2.
##Sodium and Carbs are have a high correlation with factor 3 


#Factor 1 can be health consciousness
#Factor 2 can be rich food 
#factor 3 could be flavour .

cereals$factor = cereals.factor$scores
cereals_1 = data.frame(cereals.1)

library(psych)
KMO(cereals_1)
##for sodium sampling is mderately inadequate .as kmo<0.6
##for fiber sampling is mderately inadequate .as kmo<0.6
##for cal sampling is is relatively less inadequate .
##for protein sampling is inadequate .as kmo<0.6
##for fat sampling is inadequate .as kmo<0.6
##for carbs sampling is inadequate .as kmo<0.6
#for sugar sampling is inadequate .

