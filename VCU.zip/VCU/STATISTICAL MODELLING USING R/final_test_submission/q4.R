

##ARIMA

#importing the dataset
setwd("C:/Users/e_man/OneDrive/Desktop/SCMA/FINAL TEST")
sales<- read.csv("sales.csv", header = TRUE)
names(sales)

##evaluating the dataset
head(sales$Sales,5)
head(sales$Day,5)
library(tseries)

adf.test(sales$Sales)
#H0:The data is non stationary.
#H1:The data is stationary .
##The null hypothesis is accepted and data is non stationary .

##converting it into a time series , this is madatory for arima models
sales$Sales<- ts(sales$Sales)
plot(sales$Sales)

#From the graph above it is evident that the time series does not show any trend and it has many break points.

##break points give the moments when to split the time series accordingly 
library(strucchange)
?breakpoints
break_point<- breakpoints(sales$Sales~1)
break_point
summary(break_point)
##There exist four breakpoints .
#BIC is lowest when 4 break points are taken indicating less dispersion from the actual value . 
#There are four break points in oberservation 17,38,61,97

nrow(sales)

sa<-sales$Sales
#f
##subsetting the time series as per the latest breakpoint..
sales_1<- window(sa, start= c(97), end=c(115))

##Breakpoints are however not required as the number of rows are too less.

#a
acf(sales$Sales)
##High degree of non stationariy present 
##Taking difference=1
acf(diff(sales$Sales))
#q=1, for first difference .
#the moving averages have to calcualated with a single difference and a single lag.



pacf(diff(sales$Sales))
##Due to seasonal flucutaions the third observation is beyond the critical milit .
##p=1
##(p,d,q)=(1,1,1)

##b

model_arima_number1<- arima(sales$Sales, order = c(1,1,1))
model_arima_number1
##aic=607.78
##sales(forecasted value)=.4348lag1+.7631*(error residual of lag1)

#c
acf(model_arima_number1$residuals)
##All the residuals are within the confidence interval , and no residual is crossing the margin of error.
plot(acf(model_arima_number1$residuals))

#d
Box.test(model_arima_number1$residuals, lag = 1, type = c( "Ljung-Box"), fitdf = 0) 
##Ljung Box is a derivative of chi-squared goodness of fit test.
##H0: The model is not a bad fit 
##H1: The model is a bad fit

#since p>0.05 , the null hypothesis is accepted and the model is not a bad fit for the data .

#e
library(forecast)
#25 days forecasting is required
model_arima_forecasted_value<- forecast(model_arima_number1, 25)
model_arima_forecasted_value
## the predicted value is given at 95 % and 80 % confidence interval.

#f
plot(model_arima_forecasted_value, 25)

#As visible the 95% confidence band is much higher than the 80% confidence band .
##The margin of error is higher for the 95% confidence interval , as compared to margin of error for the 80% confidence interval.

