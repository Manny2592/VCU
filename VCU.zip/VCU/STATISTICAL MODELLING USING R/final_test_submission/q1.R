
#(a)
setwd("C:/Users/e_man/OneDrive/Desktop/SCMA/FINAL TEST")
getwd()
dat = read.csv("tobit.csv")

#(b)
model_reg<-lm(Score ~ English + Maths,  data = dat)

#(c)
library(VGAM)
model_tobit <-vglm(Score ~ English + Maths , tobit(Upper = 800), data = dat)

#(d)
summary(model_reg)
summary(model_tobit)

#(e)
#In the linear regression model, it is seen that English and Maths significantly contribute to the model at 99.9% level of significance.
#The model is able to explain 58.3% of the variation in score using the independant variables English and Maths.
##H0:b1=b2-b3=0
##H1:Atleast one of the coefficients are not 0.
#The p-value of F-statistic is less than 0.01, indicating all the coefficients are significantly contributing to the model.
#A one unit increase in math is accounting for a 5.7732 unit increase in the predicted value of score
#A one unit increase in English is accounting for  a 2.7493 unit increase in the predicted value of score

#The VGLM model indicates that the English and Maths scores are significantly contributing to the score at a 99.9% confidence interval.
#A one unit increase in math is accounting for a  6.344 unit increase in the predicted value of score
#A one unit increase in English is accounting for a 2.88962 unit increase in the predicted value of score

#There exist a total of two intercepts in the tobit model , while there exist only one intercept in the linear model.
#The co-efficient values of both the models are approximately equivalent
#The degree of freedom in linear regression is 197 whereas in VGLM is 396
#The tobit model has an upper and lower limit set as it is truncated in nature, whereas the linear model has no such limits.


#(f)
#using linear model
predict(model_reg, data.frame(Maths =  42, English = 45))
#The predicted score is 558.7021

#using tobit model
predict(model_tobit, data.frame(Maths =  42, English = 45))
#555.5009 
