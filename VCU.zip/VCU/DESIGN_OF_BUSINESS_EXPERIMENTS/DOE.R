setwd("C:/Users/e_man/OneDrive/Desktop/Fn_DOE")
class_size<-read.csv("class_size.csv")

#========================================================================
#1=small,2=regular with aid,3=regular
class_size$regular_aid<-as.numeric(class_size$class==2) # dummy for display 2 (1 if display 2, 0 otherwise)
class_size$regular <-as.numeric(class_size$class==3)



m = lm(�..math~ regular_aid+regular, data=class_size) # estimate OLS regression
summary(m)

class_size$new=class_size$regular_aid+class_size$regular

model_thetha = lm(reading~ new+regular, data=class_size)

summary(model_thetha)


#===================================================================

#2

# Standard F-test

m4 = lm(�..math~1, data=class_size) # estimate restricted model with just constant
summary(m4) # restricted model results
# Calculating F-statistic
SSR.un = sum(m$residuals^2) # unrestricted SSR
SSR.r = sum(m4$residuals^2) # restricted SSR
q1 = 2 # number of restrictions
n = 5748 # number of observations
q2 = 3 # number of parameters in unrestricted model
F.statistic = ((SSR.r-SSR.un)/q1)/((SSR.un)/(n-q2))
F.statistic
# Computing p-value
p.value = pf(F.statistic, q1, n-q2, lower.tail = FALSE)
p.value
# Note: Identical values as in standard F-test
# p-values = 0.036 => If H0:b_1=b_2=0 were true, 
# there is 1 in 25 (low) chance of observing that big 
# (or bigger) F-statistic from sampling error 
# => it is unlikely that b_1=b_2=0 => it is unlikely that y = b0+u is true model
#===============================================================================
#Restricted

class_size$testing=class_size$regular_aid+class_size$regular
m_test = lm(�..math~testing, data=class_size) # estimate restricted model with just constant
summary(m_test) # restricted model results
# Calculating F-statistic
SSR.un = sum(m$residuals^2) # unrestricted SSR
SSR.r = sum(m_test$residuals^2) # restricted SSR
q1 = 1 # number of restrictions
n = 5748 # number of observations
q2 = 3 # number of parameters in unrestricted model
F.statistic = ((SSR.r-SSR.un)/q1)/((SSR.un)/(n-q2))
F.statistic
# Computing p-value
p.value = pf(F.statistic, q1, n-q2, lower.tail = FALSE)
p.value
# Note: Identical values as in standard F-test
# p-values = 0.036 => If H0:b_1=b_2=0 were true, 
# there is 1 in 25 (low) chance of observing that big 
# (or bigger) F-statistic from sampling error 
# => it is unlikely that b_1=b_2=0 => it is unlikely that y = b0+u is true model



#===============================================================================


m_1 = lm(reading~ regular_aid+regular, data=class_size) # estimate OLS regression
summary(m_1)



m4 = lm(reading~1, data=class_size) # estimate restricted model with just constant
summary(m4) # restricted model results
# Calculating F-statistic
SSR.un = sum(m_1$residuals^2) # unrestricted SSR
SSR.r = sum(m4$residuals^2) # restricted SSR
q1 = 2 # number of restrictions
n = 5748 # number of observations
q2 = 3 # number of parameters in unrestricted model
F.statistic = ((SSR.r-SSR.un)/q1)/((SSR.un)/(n-q2))
F.statistic
# Computing p-value
p.value = pf(F.statistic, q1, n-q2, lower.tail = FALSE)
p.value
# Note: Identical values as in standard F-test
# p-values = 0.036 => If H0:b_1=b_2=0 were true, 
# there is 1 in 25 (low) chance of observing that big 
# (or bigger) F-statistic from sampling error 
# => it is unlikely that b_1=b_2=0 => it is unlikely that y = b0+u is true model

#================================================================================
#math
m5 = aov(�..math ~ factor(class), data=class_size) # fit model
anova(m5) # report anova

N=5748
k=3
# between-sample estimate of variance is 24.6
s2.b = sum((m5$fitted.values-mean(class_size$�..math))^2)/(k-1)
# within-sample estimate of variance is 5.5 
s2.w = sum(m5$residuals^2)/(N-k)
F.statistic = s2.b/s2.w
F.statistic
#===============================================================================
#reading
m6 = aov(reading ~ factor(class), data=class_size) # fit model
anova(m6)

N=5748
k=3
# between-sample estimate of variance is 24.6
s2.b = sum((m6$fitted.values-mean(class_size$reading))^2)/(k-1)
# within-sample estimate of variance is 5.5 
s2.w = sum(m6$residuals^2)/(N-k)
F.statistic = s2.b/s2.w
F.statistic
